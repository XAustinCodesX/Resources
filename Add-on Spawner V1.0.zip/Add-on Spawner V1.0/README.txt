												      Add-On Vehicle Spawner V1.0
								  		 			 Made By: XAustinCodesX
							        				       Credit Goes To: Wallbanged

-- INSTALLATION --

1. Drag And Drop The "customspawner" Folder Into Your Resources Folder.
2. Edit Your "server.cfg" And Put "start customspawner" Or "ensure customspawner" In There.

-- CUSTOMIZATION -- 

- YOU CAN ADD MORE SUB-MENU'S INTO THE MENU! -

1. You Start By Opening The "client.lua" File.
2. Then You Make A New Line Where All Of The Local's Are And You Paste This Where All Of The Local's Are At The Top Of The File (Make Sure To Change The [Name Of Your Choice] And The [Name Of Car Brand]): 

local [Name Of Your Choice]VehiclesMenu = menuPool:AddSubMenu(vehiclesMenu, '[Name Of Car Brand]', "",1420, 0) 


EXAMPLE -----> local audiVehiclesMenu = menuPool:AddSubMenu(vehiclesMenu, 'Audi', "",1420, 0) 


3. Now You Paste This Into The Part After All Of The Local's:

local [Short Brand Name]VehiceMenus = {}
[Short Vehicle Name]VehiceMenus.[Short Vehicle Name][Number] = NativeUI.CreateItem('[Vehicle Name]', 'Get this vehicle.')

[Vehicle Brand Name]VehiclesMenu:AddItem([Short Vehicle Name]VehiceMenus.[Short Vehicle Name][Number])

 

EXAMPLE -----> local auVehiceMenus = {}
EXAMPLE -----> auVehiceMenus.au5 = NativeUI.CreateItem('2020 Audi R8', 'Get this vehicle.')
EXAMPLE ----->
EXAMPLE -----> audiVehiclesMenu:AddItem(auVehiceMenus.au5)  

4. Now You Paste This Into Where All Of The Coding That Looks Like This Is:

[Brand Name]VehiclesMenu.OnItemSelect = function(sender, item, index)
    if item == [Short Vehicle Name]VehiceMenus.[Short Vehicle Name][Number] then
        deleteVeh()
        spawnVehicle('[Spawn Code Of Vehicle]', '[Name Of Vehicle]')
    end
end

EXAMPLE -----> audiVehiclesMenu.OnItemSelect = function(sender, item, index)
EXAMPLE ----->     if item == auVehiceMenus.au5 then
EXAMPLE ----->         deleteVeh()
EXAMPLE ----->         spawnVehicle('aur8', '2020 Audi R8')
EXAMPLE ----->     end
EXAMPLE -----> end

- YOU CAN CHANGE THE MENU TOGGLE KEY -

1. You Start By Scrolling All The Way Down In The "client.lua" File. 
2. You Should Now See This: 

Citizen.CreateThread(function()
	while true do
	  Citizen.Wait(0)
	  menuPool:ProcessMenus()
	  if IsControlJustPressed(1,166) then 
				mainMenu:Visible(not mainMenu:Visible())
		end
	end
end)

3. Change The "166" To The Index Number Of The Keybind You Want The Menu Toggle Key To Be. To Find The Index Of The Key You Want, Go To This Link: https://docs.fivem.net/docs/game-references/controls/
(The "166" Is The Key F5, That Is The Default Menu Toggle Key)

-- CREDITS --

All Credit To Wallbanged For Doing This Original Resource. 
I Only Made It Easier For You To Add More Sub-Menu's And I Also Made A Toggle Key For The Resource (It Was Originally A Command You Had To Type In Chat).

-- HELP -- 

For Help With Anything About This Resource, Feel Free To Contact Me On Discord: T. Austin#0304


-- ENJOY -- 

Enjoy This Resource Everyone!