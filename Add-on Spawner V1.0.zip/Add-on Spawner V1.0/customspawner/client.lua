--		Created by XAustinCodesX				--
--		Custom Add-On Spawner V 1.0			    --
--        Credit To Wallbanged                  --



local menuPool = NativeUI.CreatePool()
local mainMenu = NativeUI.CreateMenu('Add-On Vehicle Spawner', "", 1420, 0) --  Enter Server Name/ Menu Name Here
local submain = menuPool:AddSubMenu(mainMenu, 'Vehicle Spawner', "", 1420, 0)
local vehiclesMenu = menuPool:AddSubMenu(submain, 'Addon Vehicles', "", 1420, 0) -- Name whatever you'd like for categorization
local policeVehiclesMenu = menuPool:AddSubMenu(vehiclesMenu, 'Bugatti',"", 1420, 0)
local sheriffVehiclesMenu = menuPool:AddSubMenu(vehiclesMenu, 'Lamborghini', "", 1420, 0)
local caroVehiclesMenu = menuPool:AddSubMenu(vehiclesMenu, 'Mercedes-Benz', "",1420, 0)
local medellinVehiclesMenu = menuPool:AddSubMenu(vehiclesMenu, 'Ferrari', "",1420, 0)
local toyotaVehiclesMenu = menuPool:AddSubMenu(vehiclesMenu, 'Toyota', "",1420, 0)
local bmwVehiclesMenu = menuPool:AddSubMenu(vehiclesMenu, 'BMW', "",1420, 0)
local audiVehiclesMenu = menuPool:AddSubMenu(vehiclesMenu, 'Audi', "",1420, 0)
local porscheVehiclesMenu = menuPool:AddSubMenu(vehiclesMenu, 'Porsche', "",1420, 0)
local acuraVehiclesMenu = menuPool:AddSubMenu(vehiclesMenu, 'Acura', "",1420, 0)
local chevroletVehiclesMenu = menuPool:AddSubMenu(vehiclesMenu, 'Chevrolet', "",1420, 0)
local cadillacVehiclesMenu = menuPool:AddSubMenu(vehiclesMenu, 'Cadillac', "",1420, 0)

local chpVehiceMenus = {} -- Mercedes-Benz
chpVehiceMenus.o2 = NativeUI.CreateItem('~r~Nothing Added Here Yet', 'Get this vehicle.') -- Change the "~r~Nothing Added Here Yet" To The Car Name You Want To Add

caroVehiclesMenu:AddItem(chpVehiceMenus.o2)

local soVehiceMenus = {} -- Lamborghini
soVehiceMenus.so12 = NativeUI.CreateItem('~r~Nothing Added Here Yet', 'Get this vehicle.')

sheriffVehiclesMenu:AddItem(soVehiceMenus.so12)

local pdVehiceMenus = {} -- Bugatti
pdVehiceMenus.pd1 = NativeUI.CreateItem('~r~Nothing Added Here Yet', 'Get this vehicle.')
pdVehiceMenus.pd7 = NativeUI.CreateItem('~r~Nothing Added Here Yet', 'Get this vehicle.')

policeVehiclesMenu:AddItem(pdVehiceMenus.pd1)
policeVehiclesMenu:AddItem(pdVehiceMenus.pd7)


local mpdVehiceMenus = {} -- Ferrari
mpdVehiceMenus.m2 = NativeUI.CreateItem('~r~Nothing Added Here Yet', 'Get this vehicle.')

medellinVehiclesMenu:AddItem(mpdVehiceMenus.m2)

local toVehiceMenus = {} -- Toyota
toVehiceMenus.t2 = NativeUI.CreateItem('~r~Nothing Added Here Yet', 'Get this vehicle.')

toyotaVehiclesMenu:AddItem(toVehiceMenus.t2)

local bmVehiceMenus = {} -- BMW
bmVehiceMenus.b2 = NativeUI.CreateItem('~r~Nothing Added Here Yet', 'Get this vehicle.')
bmVehiceMenus.b3 = NativeUI.CreateItem('~r~Nothing Added Here Yet', 'Get this vehicle.')

bmwVehiclesMenu:AddItem(bmVehiceMenus.b2)
bmwVehiclesMenu:AddItem(bmVehiceMenus.b3)

local auVehiceMenus = {} -- Audi
auVehiceMenus.a2 = NativeUI.CreateItem('~r~Nothing Added Here Yet', 'Get this vehicle.')

audiVehiclesMenu:AddItem(auVehiceMenus.a2)

local prVehiceMenus = {} -- Porsche
prVehiceMenus.p2 = NativeUI.CreateItem('~r~Nothing Added Here Yet', 'Get this vehicle.')

porscheVehiclesMenu:AddItem(prVehiceMenus.p2)

local acVehiceMenus = {} -- Acura
acVehiceMenus.ac2 = NativeUI.CreateItem('~r~Nothing Added Here Yet', 'Get this vehicle.')

acuraVehiclesMenu:AddItem(acVehiceMenus.ac2)

local chVehiceMenus = {} -- Chevrolet
chVehiceMenus.ch2 = NativeUI.CreateItem('~r~Nothing Added Here Yet', 'Get this vehicle.')

chevroletVehiclesMenu:AddItem(chVehiceMenus.ch2)

local cdVehiceMenus = {} -- Cadillac
cdVehiceMenus.cd2 = NativeUI.CreateItem('~r~Nothing Added Here Yet', 'Get this vehicle.')

cadillacVehiclesMenu:AddItem(cdVehiceMenus.cd2)


caroVehiclesMenu.OnItemSelect = function(sender, item, index) -- Mercedes-Benz
    if item == chpVehiceMenus.o2 then
        deleteVeh()
        spawnVehicle('...', 'Not Added') -- Change The "..." To The Car Spawn Code
    end
end

sheriffVehiclesMenu.OnItemSelect = function(sender, item, index) -- Lamborghini
    if item == soVehiceMenus.so12 then
        deleteVeh()
        spawnVehicle('...', 'Not Added')
    end
end

policeVehiclesMenu.OnItemSelect = function(sender, item, index) -- Bugatti
    if item == pdVehiceMenus.pd1 then
        deleteVeh()
		spawnVehicle ('...', 'Not Added')
elseif item == pdVehiceMenus.pd7 then
        deleteVeh()
		spawnVehicle ('...', 'Not Added')
	end
end

medellinVehiclesMenu.OnItemSelect = function(sender, item, index) -- Ferrari
    if item == mpdVehiceMenus.m2 then
        deleteVeh()
        spawnVehicle('...', 'Not Added')
    end
end

toyotaVehiclesMenu.OnItemSelect = function(sender, item, index) -- Toyota
    if item == toVehiceMenus.t2 then
        deleteVeh()
        spawnVehicle('...', 'Not Added')
    end
end

bmwVehiclesMenu.OnItemSelect = function(sender, item, index) -- BMW
    if item == bmVehiceMenus.b2 then
        deleteVeh()
        spawnVehicle('...', 'Not Added')
elseif item == bmVehiceMenus.b3 then
        deleteVeh()
		spawnVehicle ('...', 'Not Added')
    end
end

audiVehiclesMenu.OnItemSelect = function(sender, item, index) -- Audi
    if item == auVehiceMenus.a2 then
        deleteVeh()
        spawnVehicle('...', 'Not Added')
    end
end

porscheVehiclesMenu.OnItemSelect = function(sender, item, index) -- Porsche
    if item == prVehiceMenus.p2 then
        deleteVeh()
        spawnVehicle('...', 'Not Added')
    end
end

acuraVehiclesMenu.OnItemSelect = function(sender, item, index) -- Acura
    if item == acVehiceMenus.ac2 then
        deleteVeh()
        spawnVehicle('...', 'Not Added')
    end
end

chevroletVehiclesMenu.OnItemSelect = function(sender, item, index) -- Chevrolet
    if item == chVehiceMenus.ch2 then
        deleteVeh()
        spawnVehicle('...', 'Not Added')
    end
end

cadillacVehiclesMenu.OnItemSelect = function(sender, item, index) -- Cadillac
    if item == cdVehiceMenus.cd2 then
        deleteVeh()
        spawnVehicle('...', 'Not Added')
    end
end

---------------------------------------------------------------------------------------------------------------
--[[                           EXAMPLE
local audi = menuPool:AddSubMenu(vehiclesMenu, 'Audi', "", 1420, 0)

local aVehiclesMenus = {}

aVehiclesMenus.a8audi = NativeUI.CreateItem('2010 Audi A8', 'Get this vehicle.')
aVehiclesMenus.audirs6tk = NativeUI.CreateItem('2013 Audi RS6 Avant', 'Get this vehicle.')
aVehiclesMenus.audis8om = NativeUI.CreateItem('2014 Audi S8', 'Get this vehicle.')
aVehiclesMenus.rs7 = NativeUI.CreateItem('2015 Audi RS7', 'Get this vehicle.')

audi:AddItem(aVehiclesMenus.a8audi)
audi:AddItem(aVehiclesMenus.audirs6tk)
audi:AddItem(aVehiclesMenus.audis8om)
audi:AddItem(aVehiclesMenus.rs7)

audi.OnItemSelect = function(sender, item, index)
    if item == aVehiclesMenus.a8audi then
        deleteVeh()
        spawnVehicle ('a8audi', '2010 Audi A8')
    elseif item == aVehiclesMenus.audirs6tk then
        deleteVeh()
        spawnVehicle ('audirs6tk', '2013 Audi RS6 Avant')
    elseif item == aVehiclesMenus.audis8om then
        deleteVeh()
        spawnVehicle ('audis8om', '2014 Audi S8')
    elseif item == aVehiclesMenus.rs7 then
        deleteVeh()
        spawnVehicle ('rs7', '2015 Audi RS7')
    end
end]]

------------------------------------------------DO NOT EDIT BELOW THIS LINE---------------------------------------------------------------

function deleteVeh()
    local ped = GetPlayerPed(-1)
    if (DoesEntityExist(ped) and not IsEntityDead(ped)) then 
        local pos = GetEntityCoords(ped)

		if (IsPedSittingInAnyVehicle(ped)) then 
			local handle = GetVehiclePedIsIn(ped, false)
			NetworkRequestControlOfEntity(handle)
			SetEntityHealth(handle, 100)
			SetEntityAsMissionEntity(handle, true, true)
			SetEntityAsNoLongerNeeded(handle)
			DeleteEntity(handle)
            ShowInfo("The vehicle you were in has been deleted.")
        end
    end
end

function ShowInfo(message)
    SetNotificationTextEntry("STRING")
    AddTextComponentString(message)
    DrawNotification(0,1)
end


function spawnVehicle(vehicle, name)
        local x,y,z = table.unpack(GetOffsetFromEntityInWorldCoords(PlayerPedId(), 0.0, 8.0, 0.5))
        local color = "~y~"
        local color2 = "~r~"
        local ped = GetPlayerPed(-1)
        if DoesEntityExist(ped) then
            vehiclehash = GetHashKey(vehicle)
            RequestModel(vehiclehash)
            Citizen.CreateThread(function() 
                local waiting = 0
                while not HasModelLoaded(vehiclehash) do
                    waiting = waiting + 100
                    Citizen.Wait(100)
                    if waiting > 5000 then
                        ShowInfo(color2 .."Could not load model in time. Crash was prevented.")
                        break
                    end
                end
                local spawnedVeh = CreateVehicle(vehiclehash, x, y, z, GetEntityHeading(PlayerPedId())+90, 1, 0)
                SetPedIntoVehicle(PlayerPedId(), spawnedVeh, -1)
                SetVehicleDirtLevel(spawnedVeh, 0.0)
            end)
            ShowInfo("You have recieved the keys to a ".. color .. name .. ".")
            Wait(1000)
            return true
    end
    ShowInfo("All parking spots are currently full.")
    return false
end


function dump(o)
    if type(o) == 'table' then
       local s = '{ '
       for k,v in pairs(o) do
          if type(k) ~= 'number' then k = '"'..k..'"' end
          s = s .. '['..k..'] = ' .. dump(v) .. ','
       end
       return s .. '} '
    else
       return tostring(o)
    end
 end

menuPool:Add(mainMenu)

menuPool:RefreshIndex()

menuPool:MouseControlsEnabled(false) -- Make sure this says "false"
menuPool:ControlDisablingEnabled(true) -- Make sure this says "true"


function HelpText(text)
    SetTextComponentFormat("STRING")
    AddTextComponentString(text)
    DisplayHelpTextFromStringLabel(0, 1, 1, -1)
end

------------------------------------------------DO NOT EDIT ABOVE THIS LINE---------------------------------------------------------------

Citizen.CreateThread(function()
	while true do
	  Citizen.Wait(0)
	  menuPool:ProcessMenus()
	  if IsControlJustPressed(1,166) then -- Edit The "166" To The Index Of The Keybind You Want It To Be For The Menu To Pop Up, You Can Find Them Here: https://docs.fivem.net/docs/game-references/controls/ 
				mainMenu:Visible(not mainMenu:Visible())
		end
	end
end)

-- The "166" Is The Key F5, Which Is The Deafault Keybind For This Resource